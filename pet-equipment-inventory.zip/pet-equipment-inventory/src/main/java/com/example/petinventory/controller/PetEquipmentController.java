package com.example.petinventory.controller;

import com.example.petinventory.model.PetEquipment;
import com.example.petinventory.repository.PetEquipmentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipment")
@CrossOrigin(origins = "*")
public class PetEquipmentController {
    private final PetEquipmentRepository repository;

    public PetEquipmentController(PetEquipmentRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<PetEquipment> getAllEquipment() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PetEquipment> getEquipmentById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createEquipment(@RequestBody PetEquipment equipment) {
        ResponseEntity<String> validation = validate(equipment);
        if (validation != null) return validation;
        equipment.setId(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(equipment));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateEquipment(@PathVariable Long id,
                                             @RequestBody PetEquipment updated) {
        ResponseEntity<String> validation = validate(updated);
        if (validation != null) return validation;

        return repository.findById(id).<ResponseEntity<?>>map(existing -> {
            existing.setName(updated.getName().trim());
            existing.setCategory(updated.getCategory().trim());
            existing.setPetType(updated.getPetType() == null ? "" : updated.getPetType().trim());
            existing.setQuantity(updated.getQuantity());
            existing.setPrice(updated.getPrice());
            existing.setSupplier(updated.getSupplier() == null ? "" : updated.getSupplier().trim());
            return ResponseEntity.ok(repository.save(existing));
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEquipment(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private ResponseEntity<String> validate(PetEquipment item) {
        if (item.getName() == null || item.getName().isBlank())
            return ResponseEntity.badRequest().body("Equipment name is required.");
        if (item.getCategory() == null || item.getCategory().isBlank())
            return ResponseEntity.badRequest().body("Category is required.");
        if (item.getQuantity() < 0)
            return ResponseEntity.badRequest().body("Quantity cannot be negative.");
        if (item.getPrice() == null || item.getPrice().signum() < 0)
            return ResponseEntity.badRequest().body("Price must be zero or greater.");
        item.setName(item.getName().trim());
        item.setCategory(item.getCategory().trim());
        return null;
    }
}
