package com.example.petinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetInventoryApplication {
    public static void main(String[] args) {
        SpringApplication.run(PetInventoryApplication.class, args);
    }
}
