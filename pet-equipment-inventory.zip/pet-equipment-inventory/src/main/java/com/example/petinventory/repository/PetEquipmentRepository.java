package com.example.petinventory.repository;

import com.example.petinventory.model.PetEquipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PetEquipmentRepository extends JpaRepository<PetEquipment, Long> {
}
